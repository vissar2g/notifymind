# NotifyMind - AI Notification Filter (Android)

On-device notification filter that learns from your Keep/Dismiss votes.

## What you get
- NotificationListenerService to read notifications (with user permission)
- Room database for vote log
- On-device Naive Bayes predictor (no internet, no ML Kit needed)
- Simple UI to vote, train, and set threshold

## Build
1. Open in Android Studio (Hedgehog+)
2. Sync Gradle
3. Run on physical device (emulator can't post real notifications)
4. Grant Notification Access in Settings

## How it learns
- Every notification is tokenized: app, title, text
- You vote Keep (1) or Dismiss (0)
- Model stores word counts per class, calculates P(keep|words)
- Prediction: score 0-100, filters if below threshold


## GitHub Actions build (no Android Studio needed)
1. Create new repo on GitHub, upload these files
2. Go to Actions tab > run "Build NotifyMind APK"
3. After 3-4 min, download artifact "NotifyMind-debug-apk"
4. Install APK on phone, grant Notification Access
