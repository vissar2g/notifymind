package com.notifymind.filter

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotifyListener : NotificationListenerService() {
    private val scope = CoroutineScope(Dispatchers.IO)
    private lateinit var db: AppDatabase
    private lateinit var predictor: Predictor

    override fun onCreate() {
        super.onCreate()
        db = AppDatabase.get(this)
        predictor = Predictor(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        val extras = n.extras
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val app = sbn.packageName

        if (app == packageName) return // ignore self

        val item = NotificationItem(
            id = 0,
            packageName = app,
            title = title,
            text = text,
            postTime = sbn.postTime
        )

        scope.launch {
            db.dao().insert(item)
            val score = predictor.predict(item)
            val threshold = predictor.getThreshold()
            if (score < threshold) {
                // Auto-dismiss low-value notifications
                cancelNotification(sbn.key)
                db.dao().updateFiltered(item.id, true)
            }
        }
    }
}
